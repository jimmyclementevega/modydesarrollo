# SIGA – AgroVerde S.A.C. (prototipo)

Prototipo visual e interactivo para presentación académica. No requiere backend ni base de datos. Los datos de demostración se guardan en `localStorage` del navegador/dispositivo.

## Abrir en Visual Studio Code
1. Extrae el ZIP.
2. Abre la carpeta `siga-agroverde` en Visual Studio Code.
3. Instala la extensión **Live Server**.
4. Clic derecho en `index.html` → **Open with Live Server**.

También puedes abrir `index.html` directamente en el navegador, aunque Live Server es recomendable.

## Cobertura del desafío (requisitos RF-01 a RF-25 y reglas RN-01 a RN-12)
- Proveedores y recepción de materia prima; generación de código único de lote y consulta de trazabilidad.
- Órdenes de producción, asignación a líneas, cantidades procesadas y registro de mermas/rendimiento como campos de operación.
- Inspección de calidad con aprobación, observación, rechazo y reproceso; lotes no aprobados quedan fuera de pedidos de exportación.
- Movimientos de almacén, actualización de stock, validación de disponibilidad y alertas de inconsistencias.
- Pedidos, asociación a lotes aprobados, hitos de despacho y consulta de estado.
- Reportes de producción, inventario y trazabilidad; indicadores consolidados y auditoría de acciones.
- Gestión de usuarios y roles. Los legajos de trabajadores quedan restringidos exclusivamente al Responsable de RRHH; el Administrador del Sistema no puede consultarlos.
- Simulación de conectividad limitada y almacenamiento local para la demostración.

## Funciones simuladas
- Inicio y cierre de sesión; permite salir y volver a entrar con otro usuario.
- Menú y acciones filtrados según el rol asignado. Los usuarios creados por el administrador también aparecen en el selector de inicio de sesión.
- Roles de demostración: Administrador del Sistema, Jefe de Producción, Operario de Producción, Analista de Calidad, Jefe de Almacén, Ejecutivo Comercial / Exportaciones, Responsable de RRHH y Gerente General.
- Panel principal con indicadores y actividad.
- Registro de lotes con código correlativo único.
- Consulta y búsqueda de trazabilidad.
- Dictamen de calidad: Aprobado, Observado, Reprocesado o Rechazado.
- Órdenes de producción y asignación a las tres líneas.
- Inventario y movimientos de almacén.
- Pedidos de exportación con validación de stock y lotes aprobados.
- Notificaciones y módulos de proveedores, reportes y usuarios.
- Diseño adaptable a móvil y escritorio.

## Generar APK Android
Requisitos: Node.js LTS, Android Studio y Android SDK.

Desde la terminal de VS Code, dentro de esta carpeta:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

En Android Studio:
1. Espera a que termine la sincronización de Gradle.
2. Menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Al finalizar, usa **locate** para encontrar el APK generado.

Si modificas HTML/CSS/JS después de crear Android:
```bash
npx cap sync android
```

## Alcance y fidelidad
La aplicación se organizó según los requisitos funcionales RF-01 a RF-25, RN-01 a RN-12 y los actores descritos en el desafío. Al ser un prototipo sin backend, los perfiles, auditoría, sincronización offline y datos son demostrativos/locales; no constituyen seguridad real ni sincronización entre dispositivos. Las operaciones principales sí responden y validan reglas de negocio en la interfaz.

## Datos de demostración
Contraseña de muestra: `demo2026` para las cuentas de demostración.

### Accesos por rol (prototipo)
- Administrador del Sistema: crea usuarios y administra roles/permisos. No tiene acceso automático a legajos de RRHH.
- Jefe de Producción: trazabilidad, producción, proveedores y recepción de materia prima.
- Operario de Producción: consulta de lotes y registro de actividades de producción.
- Analista de Calidad: consulta de lotes y dictámenes de calidad.
- Jefe de Almacén: consulta de lotes e inventario/movimientos.
- Ejecutivo Comercial / Exportaciones: consulta de lotes y pedidos/exportaciones.
- Responsable de RRHH: consulta y registro de trabajadores.
- Gerente General: indicadores y reportes consolidados.

Esta separación aplica el criterio RBAC indicado en el desafío y protege los datos personales de trabajadores. Es una simulación de interfaz: no sustituye autenticación ni autorización segura en un servidor.
Los datos se guardan en el almacenamiento local del navegador. Usa el botón de cerrar sesión para cambiar de rol.

## Nota sobre el diseño de referencia
El PDF contiene la especificación de SIGA, actores, reglas y flujos, pero no se encontraron mockups gráficos de pantallas que permitan reproducir píxel por píxel una interfaz de referencia. Este prototipo respeta los nombres, módulos y reglas descritos en el documento y aplica una identidad visual agroindustrial verde, limpia y adaptable.
